# Xide

Hide posts from countries you don't want to see on X.

1. Click Xide in the sidebar
2. Add countries to block
3. Done, their posts disappear from your timeline

Everything runs locally. No backend, no analytics.

https://github.com/user-attachments/assets/986baf21-1163-4416-8560-33f7dcc363fa

## Build

Requirements:

- [Bun](https://bun.sh) 1.4 or newer (`npm install -g bun` or the installer on bun.sh)
- Linux, macOS, or Windows
- Git (optional, to clone)

```sh
git clone https://github.com/0xr3ngar/xide
cd xide
bun install
bun run build
```

`bun run build` is the build script (defined in `package.json`) and executes all
steps: it bundles `src/` into `dist/content.js` and copies `manifest.json`,
`panel.css`, `icons/`, and `README.md` into `dist/`.

## Verify with an agent if you're too lazy to read the code

```md
Validate this repo (https://github.com/0xr3ngar/xide)

1. Clone into a tmp folder, do not run install: git clone --depth 1 https://github.com/0xr3ngar/xide /tmp/xide
2. Scout the codebase to verify nothing leaves my browser
```

Just copy paste this, or run it one-shot:

```bash
claude -p "Clone https://github.com/0xr3ngar/xide into /tmp/xide (no install) and scout the codebase: verify nothing leaves my browser. Report pass/fail."
```

```bash
opencode run "Clone https://github.com/0xr3ngar/xide into /tmp/xide (no install) and scout the codebase: verify nothing leaves my browser. Report pass/fail."
```

```bash
agent -p "Clone https://github.com/0xr3ngar/xide into /tmp/xide (no install) and scout the codebase: verify nothing leaves my browser. Report pass/fail."
```

```bash
codex exec "Clone https://github.com/0xr3ngar/xide into /tmp/xide (no install) and scout the codebase: verify nothing leaves my browser. Report pass/fail."
```

```bash
pi -p "Clone https://github.com/0xr3ngar/xide into /tmp/xide (no install) and scout the codebase: verify nothing leaves my browser. Report pass/fail."
```
